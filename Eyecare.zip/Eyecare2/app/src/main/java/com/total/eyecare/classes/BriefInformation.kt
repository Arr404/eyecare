package com.total.eyecare.classes

class BriefInformation {
    var alamat: String = ""
    var perusahaan: String = ""
    var telepon: String = ""
}
