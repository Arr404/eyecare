package com.total.eyecare.classes

class camera {
    var ip:String = ""
    var thumbnail:String = ""
    var title:String = ""
}