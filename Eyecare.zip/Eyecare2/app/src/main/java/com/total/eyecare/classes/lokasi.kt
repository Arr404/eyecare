package com.total.eyecare.classes

class lokasi {
    var latitude:String = ""
    var longitude:String = ""
}